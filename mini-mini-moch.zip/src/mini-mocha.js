// let count = 0;

// global.it = function (description, fn) {
//   fn();
//   console.log(`  ✓ ${description}`);
//   count++;
// };

// require(process.argv[2]);
// console.log('');
// console.log(`  ${count} passing`);

let count = 0;
let numPassed = 0;
let numFailed = 0;
let failed = [];
let indent = 1;

function space() {
  return ' '.repeat(indent * 2);
}

function describeFunc(description, fn) {
  console.log(`${space()}${description}`);
  indent++;
  fn();
}

global.describe = function (description, fn) {
  //setTimeout(describeFunc(description, fn), 0);
  // console.log(`${space()}${description}`);
  // indent++;
  // fn();
  describeFunc(description, fn);
};

global.beforeEach = function (fn) {
  if (fn != null) {
    console.log('BEFORE');
    fn();
    // try {
    //   fn();
    // } catch (err) {
    //   console.log(`err.toString()`);
    // }
  }
};

global.it = function (description, fn) {
  try {
    count++;
    global.beforeEach();
    fn();
    console.log(`${space()}✓ ${description}`);
    numPassed++;
  } catch (err) {
    numFailed++;
    const msg = `${space()}${numFailed}) ${description}`;
    failed.push({ count: numFailed, description, err });
    console.log(`${space()}${msg}`);
  }
};

require(process.argv[2]);
console.log('');
console.log(`  ${numPassed} passing`);
if (numFailed) console.log(`  ${numFailed} failing`);
console.log('');

failed.forEach((fail) => {
  console.log(`  ${fail.count}) ${fail.description}:`);
  console.log();
  console.log('      ' + fail.err.toString());
});
