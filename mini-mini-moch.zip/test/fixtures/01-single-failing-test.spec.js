const assert = require('assert');

it('description', () => assert.equal(0, 1));
