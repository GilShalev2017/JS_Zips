const assert = require('assert');

describe('suite', () => {
  describe('sub-suite', () => {
    it('description', () => assert.equal(0, 0));
  });
});
