const assert = require('assert');

describe('suite', () => {
  it('description', () => assert.equal(0, 0));
});
