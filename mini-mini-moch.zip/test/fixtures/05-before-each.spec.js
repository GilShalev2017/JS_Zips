const assert = require('assert');

// describe('suite', () => {
//   let counter = 0;
//   beforeEach(() => counter++);
//   it('a', () => assert.equal(counter, 1));
//   it('b', () => assert.equal(counter, 2));
//   it('c', () => assert.equal(counter, 3));
// });

describe('suite', () => {
  let counter = 0;
  beforeEach(() => counter++);
  it('a', () => assert.equal(counter, 1));
  // beforeEach(() => counter++);
  it('b', () => assert.equal(counter, 2));
  // beforeEach(() => counter++);
  it('c', () => assert.equal(counter, 3));
});
