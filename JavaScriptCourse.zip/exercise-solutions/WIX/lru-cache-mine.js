class DoublyLinkedListNode {
  constructor(key, value) {
    this.key = key;
    this.value = value;
    this.next = null;
    this.prev = null;
  }
}

class LRUCache {
  constructor(capacity) {
    this.capacity = capacity;
    this.nodesNum = 0;
    this.head = null;
    this.tail = null;
    this.valueByKeyMap = new Map();
    this.nodeByKeyMap = new Map();
  }

  put(key, value) {
    //if exist
    let exist = this.valueByKeyMap.get(key);
    if (exist) {
      let foundNode = this.nodeByKeyMap.get(key);
      let foundNodePrev = foundNode.prev;
      let foundNodeNext = foundNode.next;
      foundNodePrev.next = foundNodeNext;
      foundNodeNext.prev = foundNodePrev;
      let oldHead = this.head;
      this.head = foundNode;
      this.head.next = null;
      this.head.prev = oldHead;
    } else {
      // doesn't exist
      if (this.nodesNum < this.capacity) {
        let newNode = new DoublyLinkedListNode(key, value);
        let oldHead = this.head;
        if (oldHead) oldHead.prev = newNode;
        this.head = newNode;
        this.head.next = oldHead;
        this.head.prev = null;

        if (this.tail == null) this.tail = this.head;

        this.valueByKeyMap.set(key, value);
        this.nodeByKeyMap.set(key, newNode);
        this.nodesNum++;
      } else {
        //remove old one
        let oldOne = this.tail;
        let oldOnePrev = oldOne.prev;
        oldOnePrev.next = null;
        oldOnePrev.prev = oldOne?.prev?.prev;
        this.tail = oldOnePrev;
        //delete old one to maps
        this.valueByKeyMap.delete(oldOne.key);
        this.nodeByKeyMap.delete(oldOne.key);
        let newNode = new DoublyLinkedListNode(key, value);
        if (!oldOne?.prev?.prev) oldOnePrev.prev = newNode;
        this.head = newNode;
        this.head.prev = null;
        this.head.next = oldOnePrev;
        //add new one to maps
        this.valueByKeyMap.set(key, value);
        this.nodeByKeyMap.set(key, newNode);
      }
    }
  }

  get(key) {
    let value = this.valueByKeyMap.get(key);
    if (!value) return -1;
    let foundNode = this.nodeByKeyMap.get(key);

    let foundNodePrev = foundNode.prev;
    let foundNodeNext = foundNode.next;
    if (foundNodePrev) foundNodePrev.next = foundNodeNext;
    if (foundNodeNext) foundNodeNext.prev = foundNodePrev;

    if (foundNodeNext == null) {
      this.tail = foundNodePrev;
    }

    let oldHead = this.head;
    oldHead.prev = foundNode;
    this.head = foundNode;
    this.head.next = oldHead;
    this.head.prev = null;

    return value;
  }
}

const cache = new LRUCache(2);
cache.put(1, 1);
cache.put(2, 2);
console.log(cache.get(1)); // returns 1
cache.put(3, 3);
console.log(cache.get(2)); // returns -1 (not found)
cache.put(4, 4);
