function print(text) {
  console.log(text);
}

print(1);
setTimeout(() => print(2), 0);
print(3);
