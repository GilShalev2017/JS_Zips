function convertToStringWithSpaces(input) {
  return input.split('').join(' ');
}

console.log(`turn 'hello' into ${convertToStringWithSpaces('hello')}`);
