function unique(array) {
  return array.reduce(function (acc, element) {
    var existingElement = acc.find(function (target) {
      return target === element;
    });

    if (!existingElement) {
      acc.push(element);
    }

    return acc;
  }, []);
}

const arr = [9,5,6,7,8,9,5,5,2];
const result = unique(arr);
console.log(result);