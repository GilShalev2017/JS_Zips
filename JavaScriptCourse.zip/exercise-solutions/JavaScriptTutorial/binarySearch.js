var binarySearch = function(array, value) {
    var avg;
    var min = 0;
    var max = array.length - 1;	

    while(min <= max){
        avg = Math.floor((min + max) /2);
	if(array[avg] === value)
	    return avg;
	else if(array[avg] < value)
	    min = avg + 1;
	else
	    max = avg - 1;	
     }
	
     return -1;
}

const arr = [4,5,7,11,12,15,15,21,40,45]

console.log(binarySearch(arr,11));
