function transformToObjects(numberArray) {
  // Todo: Add your logic
  // should return an array of objects
  let newArr = [];
  numberArray.forEach((elm) => newArr.push({ var: elm }));
  return newArr;
}

const arr = [1, 3, 5, 7];
res = transformToObjects(arr);
console.log(res);
