const numbers = [1, 2, 3];

function double([head, ...rest]) {
  if (!head) {
    return [];
  }

  return [2 * head, ...double(rest)];
}

console.log(double([1, 2, 3, 4]));
console.log(double([1]));
console.log(double([]));
console.log(double([, 4, 5, 6]));
