function pluck(array, property) {
  return array.map( element => {
    return element[property];
  });
}

var trips = [
  { distance: 34, time: 10 },
  { distance: 90, time: 50 },
  { distance: 59, time: 25 },
];

const newarray = pluck(trips, 'distance');
console.log(newarray);

const newarray2 = pluck(trips, 'time');
console.log(newarray2);