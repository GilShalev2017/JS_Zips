const fibonacci = (n) => {
  if (n < 3) return 1;
  return fibonacci(n - 1) + fibonacci(n - 2);
};

console.log(fibonacci(6));

function fibonacciFunc(n) {
  if (n < 3)
   return 1;
  return fibonacciFunc(n - 1) + fibonacciFunc(n - 2);
};

console.log(fibonacci(7));