function unshift(array, ...rest) {
  return [...rest, ...array];
}

console.log(unshift([3,4,5],7,8,9));