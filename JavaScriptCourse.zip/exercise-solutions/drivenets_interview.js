async function handleStateMachineStart(): Promise<any> {
    try {
        await this.startStateTimeout();
        console.log('Yotam')
    } catch(err) {
        console.log('bla bla')
    }
}

function handleStateMachineStart(): Promise<any> {
    try {
        this.startStateTimeout();
        console.log('Yotam')
    } catch(err) {
        console.log('bla bla')
    }
}