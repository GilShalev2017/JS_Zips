function findWhere(array, criteria) {
  return array.find((element) => {
    var property = Object.keys(criteria)[0];
    // console.log(property);
    return element[property] === criteria[property];
  });
}

var users = [
  { id: 21, hasSubmitted: true },
  { id: 62, hasSubmitted: 'koko' },
  { id: 4, hasSubmitted: true },
];

const criteria = {
  hasSubmitted: 'koko',
};

const found = findWhere(users, criteria);

console.log(found);

function findWhere2(array, criteria) {
  let property = Object.keys(criteria)[0];
  return array.find((element) => {
    return element[property] == criteria[property];
  });
}

var ladders = [
  { id: 1, height: 20 },
  { id: 3, height: 25 },
];

const foundItem = findWhere2(ladders, { height: 25 });

console.log(foundItem);
