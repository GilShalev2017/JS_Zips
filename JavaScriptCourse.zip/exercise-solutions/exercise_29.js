function product(...numbers) {
  return numbers.reduce(function (acc, number) {
    return acc * number;
  }, 1);
}


console.log(product(4,5,6));