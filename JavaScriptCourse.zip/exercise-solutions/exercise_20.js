function fullName(firstName, lastName) {
  return `${firstName} ${lastName}`;
}

console.log(fullName("gil","shalev"));