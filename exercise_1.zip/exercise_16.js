// function unique(array) {
//   return array.reduce(function (acc, element) {
//     var existingElement = acc.find(function (accItem) {
//       return accItem === element;
//     });

//     if (!existingElement) {
//       acc.push(element);
//     }

//     return acc;
//   }, []);
// }

function unique(array) {
  return array.reduce((acc, element) => {
    var existingElement = acc.find((accItem) => {
      return accItem === element;
    });
    if (!existingElement) {
      acc.push(element);
    }
    return acc;
  }, []);
}

const arr = [9, 5, 6, 7, 8, 9, 5, 5, 2];
const result = unique(arr);
console.log(result);
