function fib(index) {
  if (index === 1 || index === 2) {
    return 1;
  }

  return fib(index - 1) + fib(index - 2);
}

console.log(`the fib value of 3 is ${fib(3)}`);
console.log(`the fib value of 5 is ${fib(5)}`);
console.log(`the fib value of 7 is ${fib(7)}`);
