class Monster {
  constructor(options) {
    this.health = 100;
    this.name = options.name;
  }
}

console.log(new Monster({name:'gil'}));