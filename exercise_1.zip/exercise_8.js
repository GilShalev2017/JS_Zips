function reject(array, iteratorFunction) {
  return array.filter((element) => {
    return !iteratorFunction(element);
  });
}

var users = [
  { id: 1, admin: true },
  { id: 2, admin: false },
  { id: 3, admin: false },
  { id: 4, admin: false },
  { id: 5, admin: true },
];

function iteratorFunction(element) {
  if(element['id'] % 2 === 0)
    return true;
  return false;
}

const newArray = reject(users,iteratorFunction);
console.log(newArray);