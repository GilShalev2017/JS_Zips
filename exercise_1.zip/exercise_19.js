function doubleMessage(number) {
  return `Your number doubled is ${2 * number}`;
}

console.log(doubleMessage(10));