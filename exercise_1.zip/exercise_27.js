function sum(a = 0, b = 0) {
  return a + b;
}

console.log(sum(3,5));