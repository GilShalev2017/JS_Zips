const profile = {
  name: 'Alex',
  getName: function () {
    return this.name;
  },
};

console.log(profile.getName());
