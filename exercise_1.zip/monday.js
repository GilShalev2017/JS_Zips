
// const columnIdsToValues = { text: 'approved', status: 'Done', vacationDays: 1, holidays: 2 }
// const formula = 'CONCATENATE("Total: " , sum( holidays, vacationDays)';
// let finalString = formula;
// for(var prop in columnIdsToValues)
// {
//     if(formula.includes(prop)) {
//         console.log(`found ${prop} = ${columnIdsToValues[prop]}`);
//         finalString = finalString.replace(prop,columnIdsToValues[prop]);
//     }
// }
// console.log(finalString);


const formula2 = 'CONCATENATE("#first_name#", " - ", 30)';
const dic = { 'first_name': "Moshe", 'age': 20, 'status': "Done" };
let finalString2 = formula2;
for(var key in dic)
{
    if(formula2.includes(key)) {
        console.log(`found ${key} = ${dic[key]}`);
        finalString2 = finalString2.replace(key, dic[key]);
    }
}
console.log(finalString2);