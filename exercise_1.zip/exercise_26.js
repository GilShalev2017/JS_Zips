const color = 'red';

const Car = {
  color,
  drive() {
    return 'Vroom!';
  },
  getColor() {
    return this.color;
  },
};

console.log(`${Car.color} ${Car.drive()} ${Car.getColor()}`);