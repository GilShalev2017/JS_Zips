// --- Directions
// Check to see if two provided strings are anagrams of eachother.
// One string is an anagram of another if it uses the same characters
// in the same quantity. Only consider characters, not spaces
// or punctuation.  Consider capital letters to be the same as lower case
// --- Examples
//   anagrams('rail safety', 'fairy tales') --> True
//   anagrams('RAIL! SAFETY!', 'fairy tales') --> True
//   anagrams('Hi there', 'Bye there') --> False

/*
function anagrams(stringA, stringB) {
  let formattedA = stringA
    .replace(/[^\w\s]/gi, '')
    .replace(/\s+/g, '')
    .toLowerCase();

  // formattedA = formattedA.toLower();
  let formattedB = stringB
    .replace(/[^\w\s]/gi, '')
    .replace(/\s+/g, '')
    .toLowerCase();

  if (formattedA.length != formattedB.length) return false;

  let mapA = {};
  let mapB = {};

  for (let char of formattedA) {
    mapA[char] ? mapA[char]++ : (mapA[char] = 1);
  }

  for (let char of formattedB) {
    mapB[char] ? mapB[char]++ : (mapB[char] = 1);
  }

  for (let key in mapA) {
    if (!mapB[key]) return false;
    if (mapA[key] != mapB[key]) return false;
  }

  return true;
}

let res = anagrams('A tree, a life, a bench', 'A tree, a fence, a yard');
*/

/*
function anagrams(stringA, stringB) {
  const aCharMap = buildCharMap(stringA);
  const bCharMap = buildCharMap(stringB);

  if (Object.keys(aCharMap).length !== Object.keys(bCharMap).length) {
    return false;
  }

  for (let char in aCharMap) {
    if (aCharMap[char] !== bCharMap[char]) {
      return false;
    }
  }

  return true;
}

function buildCharMap(str) {
  const charMap = {};

  for (let char of str.replace(/[^\w]/g, '').toLowerCase()) {
    charMap[char] = charMap[char] + 1 || 1;
  }
  return charMap;
}
*/

// function anagrams(stringA, stringB) {
//   let cleanedStringA = stringA.replace(/[^\w]/g, '').toLowerCase();
//   let cleanedStringB = stringB.replace(/[^\w]/g, '').toLowerCase();
//   let sortedA = cleanedStringA.split('').sort().join('');
//   let sortedB = cleanedStringB.split('').sort().join('');
//   if (sortedA === sortedB) return true;
//   return false;
// }

function anagrams(stringA, stringB) {
  return cleanString(stringA) === cleanString(stringB);
}

function cleanString(str) {
  return str.replace(/[^\w]/g, '').toLowerCase().split('').sort().join('');
}

// let res = anagrams('A tree, a life, a bench', 'A tree, a fence, a yard');
let res = anagrams('hello', 'llohe');

module.exports = anagrams;
