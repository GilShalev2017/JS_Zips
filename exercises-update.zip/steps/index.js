// --- Directions
// Write a function that accepts a positive number N.
// The function should console log a step shape
// with N levels using the # character.  Make sure the
// step has spaces on the right hand side!
// --- Examples
//   steps(2)
//       '# '
//       '##'
//   steps(3)
//       '#  '
//       '## '
//       '###'
//   steps(4)
//       '#   '
//       '##  '
//       '### '
//       '####'
/*
function getPounds(num) {
  let result = '';
  for (let i = 0; i < num; i++) {
    result += '#';
  }
  return result;
}
function getSpaces(num) {
  let result = '';
  for (let i = 0; i < num; i++) {
    result += ' ';
  }
  return result;
}
function mySteps(n) {
  let result = '';
  for (let i = 1; i < n + 1; i++) {
    console.log(getPounds(i) + getSpaces(n - i));
  }
  return result;
}

let cur = 1;
function steps(n) {
  if (cur == n + 1) {
    cur = 1;
    return;
  }
  console.log(getPounds(cur) + getSpaces(n - cur));
  cur++;
  steps(n);
}
*/
function steps(n, row = 0, stair = '') {
  if (n === row) {
    return;
  }

  if (n === stair.length) {
    console.log(stair);
    return steps(n, row + 1);
  }

  const add = stair.length <= row ? '#' : ' ';
  steps(n, row, stair + add);
}

// steps(1);
// steps(2);
// steps(3);
// console.log(steps(3));

module.exports = steps;
