// --- Directions
// Print out the n-th entry in the fibonacci series.
// The fibonacci series is an ordering of numbers where
// each number is the sum of the preceeding two.
// For example, the sequence
//  [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
// forms the first ten entries of the fibonacci series.
// Example:
//   fib(4) === 3

/*
let cache = {};
cache[0] = 0;
cache[1] = 1;
cache[2] = 1;
function fib(n) {
  if (cache[n]) {
    return cache[n];
  }

  if (n < 2) {
    return n;
  }
  let result = fib(n - 1) + fib(n - 2);
  cache[n] = result;
  return result;
}
*/
function memoize(fn) {
  const cache = {};
  return function (...args) {
    if (cache[args]) {
      return cache[args];
    }
    const result = fn.apply(this, args);
    cache[args] = result;
    return result;
  };
}

function slowFib(n) {
  if (n < 2) return n;
  return slowFib(n - 1) + slowFib(n - 2);
  //   return fib(n - 1) + fib(n - 2);
}
const fib = memoize(slowFib);
// fib(5, 6, 7);
/*
function myfib(n) {
  if (n == 1 || n == 2) {
    return 1;
  }
  counter = 0;
  first = 1;
  second = 1;
  let sum = 0;
  for (let i = 3; i <= n; i++) {
    sum = first + second;
    first = second;
    second = sum;
  }
  return sum;
}
*/
// console.log(fib(1));
// console.log(fib(2));
// console.log(fib(3));
// console.log(fib(4));
// console.log(fib(5));
// console.log(fib(6));
module.exports = fib;
