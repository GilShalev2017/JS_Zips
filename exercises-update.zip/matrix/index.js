// --- Directions
// Write a function that accepts an integer N
// and returns a NxN spiral matrix.
// --- Examples
//   matrix(2)
//     [[1, 2],
//     [4, 3]]
//   matrix(3)
//     [[1, 2, 3],
//     [8, 9, 4],
//     [7, 6, 5]]
//  matrix(4)
//     [[1,   2,  3, 4],
//     [12, 13, 14, 5],
//     [11, 16, 15, 6],
//     [10,  9,  8, 7]]
// col,row,col,row,col,row,col
// 4,   3, 3,  2,  2,  1,  1
/*
function matrix(n) {
  let arr = [];
  for (let i = 0; i < n; i++) {
    let tempArr = [];
    for (let j = 0; j < n; j++) {
      tempArr.push(-9);
    }
    arr.push(tempArr);
  }
  let row = 0;
  let col = 0;
  let isCol = true;
  let digit = 1;
  let segment = n;
  let colDirection = '+';
  let rowDirection = '+';
  //   3,2,2,1,1

  while (digit <= n * n) {
    if (isCol) {
      //fixed row, col changing
      if (colDirection == '+') {
        for (let j = col; j < col + segment; j++) {
          arr[row][j] = digit;
          digit++;
        }
        col += segment - 1;
        row++;
      } else {
        for (let j = col; j < 0; j--) {
          arr[row][j] = digit;
          digit++;
        }
        col -= segment;
        row--;
      }
      colDirection = '-';
      isCol = false;
      segment--;
    } else {
      //fixed col, row changing
      if (rowDirection == '+') {
        for (let j = row; j < row + segment; j++) {
          arr[j][col] = digit;
          digit++;
        }
        row += segment - 1;
        col++;
      } else {
        for (let j = row; j < 0; j--) {
          arr[row][col] = digit;
          digit++;
        }
        row -= segment;
        col--;
      }
      rowDirection = '-';
      isCol = true;
      segment--;
    }
  }
  console.log(arr);
}
*/

function matrix(n) {
  let startRow = 0;
  let endRow = n - 1;
  let startCol = 0;
  let endCol = n - 1;
  let counter = 1;
  let arr = [];

  for (let i = 0; i < n; i++) {
    arr.push([]);
  }

  while (counter <= n * n) {
    for (let i = startCol; i <= endCol; i++) {
      arr[startRow][i] = counter;
      counter++;
    }
    startRow++;
    for (let i = startRow; i <= endRow; i++) {
      arr[i][endCol] = counter;
      counter++;
    }
    endCol--;
    for (let i = endCol; i >= startCol; i--) {
      arr[endRow][i] = counter;
      counter++;
    }
    endRow--;
    for (let i = endRow; i >= startRow; i--) {
      arr[i][startCol] = counter;
      counter++;
    }
    startCol++;
  }
  return arr;
}
matrix(5);
module.exports = matrix;
