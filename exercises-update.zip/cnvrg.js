const tree = {
  dir: {
    type: 'dir',
    content: {
      dir1: {
        type: 'dir',
        content: {
          dir1_1: {
            type: 'dir',
            content: {
              file1_1_1: {
                type: 'file',
                size: '1k',
              },
              file1_1_2: {
                type: 'file',
                size: '2k',
              },
            },
          },
          file1_1: {
            type: 'file',
            size: '3k',
          },
          file1_2: {
            type: 'file',
            size: '4k',
          },
        },
      },
      file1: {
        type: 'file',
        size: '5k',
      },
      file2: {
        type: 'file',
        size: '6k',
      },
    },
  },
  file: {
    type: 'file',
    size: '5k',
  },
};

function printTreePaths(tree, basePath = []) {
  for (const key in tree) {
    if (tree.hasOwnProperty(key)) {
      const newPath = [...basePath, key]; // Append current key to the basePath
      if (tree[key].type === 'dir' && tree[key].content) {
        // If current node is a directory, recursively call the function on its content
        printTreePaths(tree[key].content, newPath);
      } else {
        // Reached a file node, print the path
        console.log(newPath.join('/'));
      }
    }
  }
}

printTreePaths(tree);

/*
/dir 
/dir/dir1 
/dir/dir1/dir1_1 
/dir/dir1/dir1_1/file1_1_1 - 1k 
/dir/dir1/dir1_1/file1_1_2 - 2k 
/dir/dir1/file1_1 - 3k
/dir/dir1/file1_2 - 4k
/dir/file1 - 5k
/dir/file2 - 6k
/file - 5k
*/

/*
/dir 
/dir/dir1 
/dir/dir1/dir1_1 







*/
