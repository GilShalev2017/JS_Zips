// --- Directions
// Given a string, return a new string with the reversed
// order of characters
// --- Examples
//   reverse('apple') === 'leppa'
//   reverse('hello') === 'olleh'
//   reverse('Greetings!') === '!sgniteerG'

/*
function reverse(str) {
  return str.split('').reverse().join('');
}
*/

/*
function reverse(str) {
  let result = '';
  for (let char of str) {
    result = char + result;
  }
  return result;
}
*/
// console.log(reverse('abcde'));

function reverse(str) {
  let arr = str.split('');
  let acc = '';
  acc = arr.reduce((acc, item) => {
    return (acc = item + acc);
  }, '');

  return acc;
}

module.exports = reverse;

// function reverse(str) {
//   let length = str.length;
//   let halfLength = length / 2;

//   let leftArr = [];
//   let rightArr = [];
//   for (let i = 0; i < halfLength; i++) {
//     let beginChar = str[i];
//     let endChar = str[length - 1 - i];
//     rightArr.unshift(beginChar);
//     leftArr.push(endChar);
//   }
//   return leftArr.concat(rightArr).join('');
// }
