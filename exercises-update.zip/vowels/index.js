// --- Directions
// Write a function that returns the number of vowels
// used in a string.  Vowels are the characters 'a', 'e'
// 'i', 'o', and 'u'.
// --- Examples
//   vowels('Hi There!') --> 3
//   vowels('Why do you ask?') --> 4
//   vowels('Why?') --> 0

/*
function vowels(str) {
  //   let vowles = 'aeiou';
  let vowles = ['a', 'e', 'i', 'o', 'u'];

  let counter = 0;
  for (let char of str.toLowerCase()) {
    if (vowles.includes(char)) {
      counter++;
    }
  }
  return counter;
}
*/
function vowels(str) {
  let macthes = str.match(/[aeiou]/gi);
  return macthes ? macthes.length : 0;
}

vowels('bcdfghjkl');
module.exports = vowels;
