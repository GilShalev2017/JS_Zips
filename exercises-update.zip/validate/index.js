// --- Directions
// Given a node, validate the binary search tree,
// ensuring that every node's left hand child is
// less than the parent node's value, and that
// every node's right hand child is greater than
// the parent
const Node = require('./node');

function inOrder(node, arr) {
  if (!node) {
    return;
  }
  inOrder(node.left, arr);
  arr.push(node.data);
  inOrder(node.right, arr);
}

function validate(node, min = null, max = null) {
  let inOrderArr = [];
  inOrder(node, inOrderArr);
  for (let i = 0; i < inOrderArr.length - 1; i++) {
    if (inOrderArr[i] > inOrderArr[i + 1]) {
      return false;
    }
  }
  return true;
}
const n = new Node(10);
n.insert(5);
n.insert(15);
n.insert(0);
n.insert(20);
n.left.left.right = new Node(999);

let result = validate(n);
module.exports = validate;
