// --- Directions
// Implement classes Node and Linked Lists
// See 'directions' document

class Node {
  constructor(data, next = null) {
    this.data = data;
    this.next = next;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
    // this.size = 0;
  }
  insertFirst(data) {
    this.head = new Node(data, this.head);
    // this.size++;
  }
  size() {
    let counter = 0;
    let node = this.head;

    while (node) {
      counter++;
      node = node.next;
    }

    return counter;
  }
  getFirst() {
    return this.head;
  }
  getLast() {
    let current = this.head;
    while (current && current.next) {
      current = current.next;
    }
    return current;
  }
  clear() {
    this.head = null;
  }
  removeFirst() {
    if (this.head) {
      this.head = this.head.next;
    }
  }
  removeLast() {
    if (!this.head) return;

    if (!this.head.next) {
      this.head = null;
      return;
    }

    let prev = this.head;
    let current = this.head.next;

    while (current.next) {
      prev = current;
      current = current.next;
    }
    prev.next = null;
  }
  insertLast(data) {
    let last = this.getLast();

    let newNode = new Node(data);

    if (last == null) {
      this.head = newNode;
    } else {
      last.next = newNode;
    }
  }

  getAt(index) {
    if (index === 0) return this.head;

    if (index > this.size() - 1) return null;

    let counter = 0;
    let node = this.head;
    while (node) {
      if (counter === index) return node;
      counter++;
      node = node.next;
    }

    return null;
  }

  removeAt(index) {
    if (index === 0) {
      this.head = this.head?.next || null;
    }
    if (index > this.size() - 1) return null;
    let prevNode = this.getAt(index - 1);
    if (prevNode) {
      prevNode.next = prevNode.next?.next;
    }
  }
  insertAt(data, index) {
    let newNode = new Node(data);

    if (index === 0) {
      if (!this.head) {
        this.head = newNode;
        return;
      } else {
        let oldHead = this.head;
        this.head = newNode;
        this.head.next = oldHead;
        return;
      }
    }

    let prev = this.getAt(index - 1);
    if (prev) {
      let after = prev.next;
      prev.next = newNode;
      newNode.next = after;
    } else {
      let last = this.getLast();
      if (!last) this.head = last;
      else last.next = newNode;
    }
  }

  forEach(fn) {
    let node = this.head;
    let counter = 0;
    while (node) {
      fn(node, counter);
      node = node.next;
      counter++;
    }
  }

  *[Symbol.iterator]() {
    let node = this.head;
    while (node) {
      yield node;
      node = node.next;
    }
  }
}

// const node1 = {
//   data: 123,
// };
// const node2 = {
//   data: 456,
// };
// node1.next = node2;

// const tmp = new LinkedList(123);
// const l = new LinkedList();
// // l.removeLast();
// // l.insertFirst('a');
// // l.removeLast();
// l.insertFirst('b');
// l.insertFirst('a');
// l.removeLast();

module.exports = { Node, LinkedList };
