// --- Directions
// Given a string, return the character that is most
// commonly used in the string.
// --- Examples
// maxChar("abcccccccd") === "c"
// maxChar("apple 1231111") === "1"

// function maxChar(str) {
//   let myMap = new Map();
//   for (let char of str) {
//     if (myMap.get(char) != null) {
//       myMap.set(char, myMap.get(char) + 1);
//     } else {
//       myMap.set(char, 1);
//     }
//   }
//   let counter = 0;
//   let maxChar = '';

//   for (const key of myMap.keys()) {
//     if (myMap.get(key) > counter) {
//       counter = myMap.get(key);
//       maxChar = key;
//     }
//   }
//   return maxChar;
// }

function maxChar(str) {
  let chars = {};
  for (let char of str) {
    chars[char] ? chars[char]++ : (chars[char] = 1);
  }
  let counter = 0;
  let maxChar = '';
  for (let key in chars) {
    if (chars[key] > counter) {
      counter = chars[key];
      maxChar = key;
    }
  }

  return maxChar;
}

// maxChar('abcccccccd');

module.exports = maxChar;
